export function byLabel(a, b) {
	return a.label.localeCompare(b.label);
}
