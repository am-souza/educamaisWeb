import React from "react";

export function PanelContent(props) {
	return <div className="p-grid" {...props}/>;
}
