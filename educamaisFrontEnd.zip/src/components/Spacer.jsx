import React from "react";

export function Spacer() {
	return <div style={{height: "10px"}}/>;
}
