import React from "react";
import "./Components.scss";

export function PanelFooter(props) {
	return <div className="panel-footer" {...props}/>;
}
